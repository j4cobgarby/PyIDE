/**
 * @author j4cobgarby
 * 
 * This package contains the necessary classes for
 * my Python IDE.
 * 
 * The Main class is, of course, the main class, and
 * is used to basically display the window and it's
 * properties.
 * 
 * The Helpers class could be used in any swing project really
 * (Well, some of it's functions), but some of them are specific
 * to this.
 */

package io.j4cobgarby.github;