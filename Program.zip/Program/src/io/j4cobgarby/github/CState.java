package io.j4cobgarby.github;

public enum CState {
	DEBUG, // So should use internal prefs.json
	RELEASE // So should use prefs.json contained in folder
}
