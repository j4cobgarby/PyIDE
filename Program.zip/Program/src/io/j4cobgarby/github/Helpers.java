package io.j4cobgarby.github;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import org.apache.commons.io.FilenameUtils;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;

public class Helpers {
	/*
	 * Checks if a given path exists
	 */
	public static boolean checkPath(String path) {
		return new File(path).exists();
	}

	/*
	 * Create a new file from a String path
	 */
	static void newFile(String path) {
		File file = new File(path);
		try {
			file.createNewFile();
			loadFile(path);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(Main.frame, "Can't create this file.");
			e.printStackTrace();
		}
	}

	/*
	 * Save a file to a String path
	 */
	static void saveFile(String saveTo) {
		FileWriter fwrite = null;
		try {
			fwrite = new FileWriter(new File(saveTo), false);
		} catch (IOException e1) {
			JOptionPane.showMessageDialog(Main.frame, "Can't open or create save file.");
			e1.printStackTrace();
		}

		try {
			fwrite.write(Main.area.getText());
			fwrite.close();
		} catch (IOException e1) {
			JOptionPane.showMessageDialog(Main.frame, "Can't save.");
			e1.printStackTrace();
		}
		System.out.println("Saved " + Main.currentFile);
	}

	/*
	 * Used with the caret position display; the actual output
	 */
	static void updateStatus(int linenumber, int columnnumber) {
		Main.status.setText(linenumber + ":" + columnnumber);
	}

	/*
	 * Loads a file to JTextArea area from a String path
	 */
	static void loadFile(String filepath) {
		try {
			Main.area.setText(readFile(filepath, Charset.defaultCharset()));
			Main.filenameLabel.setText(new File(filepath).getName());
			String ext = FilenameUtils.getExtension(filepath);

			if (ext.equals("py") || ext.equals("json") || ext.equals("rb")) {
				switch (ext) {
				case "py":
					Main.area.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_PYTHON);
					Main.btnRun.setText("Run in Python");
					JOptionPane.showMessageDialog(Main.frame, "went through switch and got python");
					Main.btnRun.setEnabled(true);
					break;
				case "json":
					Main.area.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JSON);
					Main.btnRun.setText("Can't run this.");
					Main.btnRun.setEnabled(false);
					break;
				case "rb":
					Main.area.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_RUBY);
					Main.btnRun.setText("Run in Ruby");
					Main.btnRun.setEnabled(true);
					break;
				
				default:
					break;
				}
			} else
				Main.btnRun.setText("Can't run this.");
				Main.btnRun.setEnabled(false);
				Main.area.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_NONE);

			Main.currentFile = filepath;
		} catch (IOException e1) {
			JOptionPane.showMessageDialog(Main.frame, "File not found.");
			e1.printStackTrace();
		}
	}

	/*
	 * Reads a file from a String path with Charset encoding and returns it as a
	 * String
	 */
	static String readFile(String path, Charset encoding) throws IOException {
		byte[] encoded = Files.readAllBytes(Paths.get(path));
		return new String(encoded, encoding);
	}

	/*
	 * Returns a string of an InputStream as a string
	 */
	static String convertStreamToString(java.io.InputStream is) {
		Main.scanner = new java.util.Scanner(is);
		java.util.Scanner s = Main.scanner.useDelimiter("\\A");
		return s.hasNext() ? s.next() : "";
	}

	/*
	 * Runs the current file as Python in cmd.
	 */
	public static void runPython(String cmdPrefix) {
		if (Main.osType != "win") {
			JOptionPane.showMessageDialog(Main.frame, 
					"Sorry - you can't use the command line utilities unless you're on windows.\n"
					+ "If you are on windows, and believe this to be a mistake, contact me.");
			return;
		}
		if (Main.currentFile == null) {
			System.out.println("File is null");
			JOptionPane.showMessageDialog(Main.frame, "No file loaded :(");
			return;
		}
		Runtime rt = Runtime.getRuntime();
		String pyCmd = cmdPrefix + " \"" + Main.currentFile + "\"";
		try {
			rt.exec("cmd.exe /c start cmd.exe /k \"" + pyCmd + "\"");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void ruby(String cmdPrefix) {
		if (Main.osType != "win") {
			JOptionPane.showMessageDialog(Main.frame, 
					"Sorry - you can't use the command line utilities unless you're on windows.\n"
					+ "If you are on windows, and believe this to be a mistake, contact me.");
			return;
		}
		if (Main.currentFile == null) {
			System.out.println("File is null");
			JOptionPane.showMessageDialog(Main.frame, "No file loaded :(");
			return;
		}
		Runtime rt = Runtime.getRuntime();
		String rbCmd = cmdPrefix + " \"" + Main.currentFile + "\"";
		try {
			rt.exec("cmd.exe /c start cmd.exe /k \"" + rbCmd + "\"");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getFilePathFromChooser() {
		JFileChooser chooser = new JFileChooser();
		chooser.setCurrentDirectory(new File(System.getProperty("user.home")));
		chooser.setDialogTitle("File selection");
		chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		chooser.setAcceptAllFileFilterUsed(false);

		if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			System.out.println("getCurrentDirectory(): " + chooser.getCurrentDirectory());
			System.out.println("getSelectedFile() : " + chooser.getSelectedFile());
			return chooser.getSelectedFile().getAbsolutePath().toString();
		} else {
			System.out.println("No Selection ");
			return "No selection";
		}
	}
}
