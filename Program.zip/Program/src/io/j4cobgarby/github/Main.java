package io.j4cobgarby.github;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;

import javax.swing.AbstractAction;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import org.apache.commons.io.FilenameUtils;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import org.json.JSONException;
import org.json.JSONObject;

import de.javasoft.plaf.synthetica.SyntheticaPlainLookAndFeel;

public class Main {
	CState state = CState.RELEASE;

	public static JFrame frame;
	public JTextField textField;
	
	public static JButton btnRun;

	public static String currentFile = null;
	static java.util.Scanner scanner;
	public JTextField cmd2Run;

	public JSONObject prefs = null;

	static String osType = "Unknown";

	static RSyntaxTextArea area = new RSyntaxTextArea();

	static JLabel filenameLabel = new JLabel("");
	static JTextField status;

	static File prefsFile;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					@SuppressWarnings("unused")
					Main window = new Main();
					Main.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/*
	 * This function sets up all the components.
	 */
	public void setup() throws IOException, JSONException {
		String prefsText = "";

		area.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_S, KeyEvent.CTRL_DOWN_MASK), "save");
		area.getActionMap().put("save", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1886521752159855366L;

			@Override
			public void actionPerformed(ActionEvent arg0) {
				Helpers.saveFile(currentFile);
				if (currentFile.equals(prefsFile.getAbsolutePath())) {
					// JOptionPane.showMessageDialog(Main.frame, "Restart the
					// program to update prefs changes.");
					
					//JOptionPane.showConfirmDialog(Main.frame, "Restart the program to update prefs changes.");
					int response = JOptionPane.showConfirmDialog(null, 
							"Python IDE must be restarted to apply the changes. Would you like to exit now?", 
							"Prefs edited",
							JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
							
					if (response == JOptionPane.NO_OPTION) {
						System.out.println("'NO' button clicked");
					} 
					else if (response == JOptionPane.YES_OPTION) {
						System.out.println("'YES' button clicked");
						System.exit(0);
					} 
					else if (response == JOptionPane.CLOSED_OPTION) {
						System.out.println("JOptionPane closed");
					}
				}
			}

		});

		if (state == CState.DEBUG) {
			JOptionPane.showMessageDialog(Main.frame,
					Helpers.convertStreamToString(Main.class.getResourceAsStream("prefs.json")));
			prefsText = Helpers.convertStreamToString(Main.class.getResourceAsStream("prefs.json"));
			prefsFile = new File("prefs.json");
		} else if (state == CState.RELEASE) {
			if (!Helpers.checkPath("prefs.json"))
				new File("prefs.json").createNewFile();
			String prefsPath = "./prefs.json";
			FileInputStream fis = new FileInputStream(prefsPath);
			prefsText = Helpers.convertStreamToString(fis);

			prefsFile = new File(prefsPath);
		}

		System.out.println(prefsFile.getAbsolutePath().toString());

		osType = (System.getProperty("os.name").startsWith("Windows") ? "win" : "unix");
		System.out.println(osType);
		if (osType == "unix") {
			JOptionPane.showMessageDialog(Main.frame, 
					"Sorry - Unix systems are not currently supported.", 
					"OS Error", JOptionPane.ERROR_MESSAGE);
		}

		try {
			prefs = new JSONObject(prefsText);
		} catch (JSONException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(Main.frame,
					"Error occured whilst parsing prefs.json\nCheck your prefs.json for incorrect commas.",
					"JSON Error", JOptionPane.ERROR_MESSAGE);
		}

		@SuppressWarnings("unused")
		String pyCommand;
		String rbCommand;
		
		pyCommand = (String) prefs.getString("pyCommandWin");
		
		rbCommand = (String) prefs.getString("rbCommandWin");
		
		String lastFile = (String) prefs.get("lastFile");
		int tabSize = prefs.getInt("tabSize");
		area.setTabSize(tabSize);

		area.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				JTextArea editArea = (JTextArea) e.getSource();

				int linenum = 1;
				int columnnum = 1;

				try {
					int caretpos = editArea.getCaretPosition();
					linenum = editArea.getLineOfOffset(caretpos);

					columnnum = caretpos - editArea.getLineStartOffset(linenum);

					linenum += 1;
				} catch (Exception ex) {
				}

				Helpers.updateStatus(linenum, columnnum);
			}
		});

		frame.getContentPane().add(area, BorderLayout.CENTER);

		status = new JTextField();
		frame.getContentPane().add(status, BorderLayout.SOUTH);

		Helpers.updateStatus(1, 1);

		System.out.println(System.getProperty("os.name") + " is " + osType);

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
		} catch (InstantiationException e2) {
			e2.printStackTrace();
		} catch (IllegalAccessException e2) {
			e2.printStackTrace();
		} catch (UnsupportedLookAndFeelException e2) {
			e2.printStackTrace();
		}
		frame.setTitle("Python IDE");
		JToolBar toolBar = new JToolBar();
		toolBar.setFloatable(false);
		frame.getContentPane().add(toolBar, BorderLayout.NORTH);

		Component horizontalStrut_2 = Box.createHorizontalStrut(20);
		toolBar.add(horizontalStrut_2);

		// Syntax highlighting stuff
		area.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_NONE);
		area.setCodeFoldingEnabled(true);

		area.setFont(new Font("Courier New", Font.PLAIN, 12));
		// area.setText(convertStreamToString(Main.class.getResourceAsStream("help.txt")));
		area.setText((lastFile.isEmpty()) ? Helpers.convertStreamToString(Main.class.getResourceAsStream("help.txt"))
				: Helpers.readFile(lastFile, Charset.defaultCharset()));
		frame.getContentPane().add(area, BorderLayout.CENTER);

		filenameLabel.setFont(new Font("Tahoma", Font.PLAIN, 11));
		filenameLabel.setToolTipText("File name");
		toolBar.add(filenameLabel);
		filenameLabel.setText("Untitled");

		Component horizontalStrut_6 = Box.createHorizontalStrut(20);
		toolBar.add(horizontalStrut_6);
		
		btnRun = new JButton("Can't run this.");
		btnRun.setEnabled(false);
		try {
			btnRun.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					// cmd2Run.setText(pyCommandWin + " " + currentFile);
					//Helpers.runPython(pyCommand);
					String ext = FilenameUtils.getExtension(currentFile);
					
					switch (ext) {
					case "py":
						Helpers.runPython(pyCommand);
						break;
					case "rb":
						Helpers.ruby(rbCommand);
						break;
					default:
						break;
					}
				}
			});
		} catch (Exception e) {
			System.out.println("Error");
		}
		toolBar.add(btnRun);

		Component horizontalStrut_1 = Box.createHorizontalStrut(20);
		toolBar.add(horizontalStrut_1);

		Component horizontalStrut_7 = Box.createHorizontalStrut(2);
		toolBar.add(horizontalStrut_7);

		JButton btnRunThisCommand = new JButton("Run this command");
		btnRunThisCommand
				.setToolTipText("Use this for running a script in a different language, or for command line args.");
		btnRunThisCommand.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Main.osType != "win") {
					JOptionPane.showMessageDialog(Main.frame, 
							"Sorry - you can't use the command line utilities unless you're on windows.\n"
							+ "If you are on windows, and believe this to be a mistake, contact me.");
					return;
				}

				Runtime rt = Runtime.getRuntime();
				try {
					rt.exec("cmd.exe /c start cmd.exe /k \"" + cmd2Run.getText() + "\"");
				} catch (IOException e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(Main.frame, "Error running file", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		toolBar.add(btnRunThisCommand);

		cmd2Run = new JTextField();
		cmd2Run.setToolTipText("Use this for running a script in a different language, or for command line args.");
		cmd2Run.setHorizontalAlignment(SwingConstants.LEFT);
		cmd2Run.setFont(new Font("Courier New", Font.PLAIN, 11));
		toolBar.add(cmd2Run);
		cmd2Run.setColumns(5);

		Component horizontalStrut = Box.createHorizontalStrut(300);
		toolBar.add(horizontalStrut);

		textField = new JTextField();

		// When ENTER is pressed, loadFromField action is called
		textField.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "loadFromField");

		// This says what happens with the key loadFromField, used just above
		textField.getActionMap().put("loadFromField", new AbstractAction() {

			/**
			 * 
			 */
			private static final long serialVersionUID = 871781328994929992L;

			@Override
			public void actionPerformed(ActionEvent arg0) {
				Helpers.loadFile(textField.getText());
			}

		});

		textField.setHorizontalAlignment(SwingConstants.RIGHT);
		textField.setText(new File(System.getProperty("user.home")).toString());
		toolBar.add(textField);
		textField.setColumns(10);

		JButton btnLoadFile = new JButton("Load file");
		btnLoadFile.setHorizontalAlignment(SwingConstants.RIGHT);
		btnLoadFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Helpers.loadFile(textField.getText());
			}

		});
		toolBar.add(btnLoadFile);

		JToolBar toolBar_1 = new JToolBar();
		toolBar_1.setFloatable(false);
		frame.getContentPane().add(toolBar_1, BorderLayout.SOUTH);

		status = new JTextField();
		status.setEditable(false);
		toolBar_1.add(status);
		status.setColumns(10);

		JButton btnSettings = new JButton("Settings");
		btnSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (state != CState.DEBUG) {
					Helpers.loadFile(Main.prefsFile.getAbsolutePath().toString());
				} else {
					JOptionPane.showMessageDialog(Main.frame, "This feature is not available in the debug version.");
				}
			}
		});
		toolBar_1.add(btnSettings);

		/*
		 * JScrollPane scrollPane = new JScrollPane(textPane); TextLineNumber
		 * tln = new TextLineNumber(textPane); scrollPane.setRowHeaderView( tln
		 * );
		 */

		JScrollPane scrollPane = new JScrollPane(area);
		frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

		Component horizontalStrut_3 = Box.createHorizontalStrut(5);
		scrollPane.setRowHeaderView(horizontalStrut_3);

		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);

		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);

		JMenuItem mntmSaveCurrentFile = new JMenuItem(new AbstractAction("Save file") {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				Helpers.saveFile(currentFile);
				if (currentFile == prefsFile.getAbsolutePath()) {
					JOptionPane.showMessageDialog(Main.frame, "Restart the program to update prefs changes.");
				}
			}
		});

		mntmSaveCurrentFile.setText("Save");
		mnFile.add(mntmSaveCurrentFile);

		JMenuItem mntmSaveUnderDifferent = new JMenuItem(new AbstractAction("Save file as..") {
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				JTextField saveFileName = new JTextField(System.getProperty("user.home"));
				JPanel panel = new JPanel(new GridLayout(0, 1));
				panel.add(new JLabel("What would you like to save this file as?"));
				panel.add(saveFileName);
				int result = JOptionPane.showConfirmDialog(null, panel, "Save as..", JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.PLAIN_MESSAGE);
				if (result == JOptionPane.OK_OPTION) {
					// On OK
					Helpers.saveFile(saveFileName.getText());
				} else {
					System.out.println("Cancelled");
				}
			}
		});
		mntmSaveUnderDifferent.setText("Save as..");
		mnFile.add(mntmSaveUnderDifferent);

		JMenuItem mntmCreateNewFile = new JMenuItem(new AbstractAction("Create new file") {
			/**
			 * 
			 */
			private static final long serialVersionUID = -8931216834017548525L;

			public void actionPerformed(ActionEvent e) {
				JTextField newFilePath = new JTextField(System.getProperty("user.home"));
				JPanel panel = new JPanel(new GridLayout(0, 1));
				panel.add(new JLabel("Path for new file:"));
				panel.add(newFilePath);
				int result = JOptionPane.showConfirmDialog(null, panel, "New file", JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.PLAIN_MESSAGE);
				if (result == JOptionPane.OK_OPTION) {
					// On OK
					Helpers.newFile(newFilePath.getText());
				} else {
					System.out.println("Cancelled");
				}
			}
		});
		mntmCreateNewFile.setText("New file..");
		mnFile.add(mntmCreateNewFile);

		JMenuItem mntmLoadFile = new JMenuItem(new AbstractAction("Load file") {
			/**
			 * 
			 */
			private static final long serialVersionUID = 8749817516468855985L;

			public void actionPerformed(ActionEvent e) {
				Helpers.loadFile(Helpers.getFilePathFromChooser());
			}
		});
		mntmLoadFile.setText("Load");
		mnFile.add(mntmLoadFile);
		
		JMenu mnRun = new JMenu("Run..");
		menuBar.add(mnRun);
		
		JMenuItem mntmInPython = new JMenuItem(new AbstractAction("in Python") {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				Helpers.runPython(pyCommand);
			}
			
		});
		mnRun.add(mntmInPython);
		
		JMenuItem mntmInRuby = new JMenuItem(new AbstractAction("in Ruby") {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				Helpers.ruby(rbCommand);
			}
			
		});
		mnRun.add(mntmInRuby);
	}

	/**
	 * Create the application.
	 * 
	 * @throws IOException
	 * @throws JSONException
	 */
	public Main() throws IOException, JSONException {
		initialize();

		setup();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 938, 618);
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				if (JOptionPane.showConfirmDialog(frame, "Are you sure you wish to exit?", "Quit",
						JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
					try {
						System.out.println("Exiting");
						System.out.println(prefs.toString(4));
					} catch (JSONException e) {
						e.printStackTrace();
					}
					System.exit(0);
				}
			}
		});
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	}
}
