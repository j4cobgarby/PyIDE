
Written by Jacob Garby (
	j4cobgarby on github,
	j.garby@icloud.com or j4cobgarby@gmail.com)

########################## CONTACT ###############################

Contact me if you have any questions about this program, or would
like to make a suggestion as to what I should implement in the
future - any suggestions or questions are welcomed.

######################## OPEN SOURCE #############################

The source code is available on my github - feel free to modify
the code in any way, but without distrobuting any of my code.

######################## CONTRIBUTIONS ###########################

If you've made an improvement to the code and feel it could be in
the release version of the program, contact me and I'll have a look.
I'll give credit to any used contributions made.

