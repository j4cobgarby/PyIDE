
Written by Jacob Garby (
	j4cobgarby on github,
	j.garby@icloud.com or j4cobgarby@gmail.com
)

########################## CONTACT ###############################

Contact me if you have any questions about this program, or would
like to make a suggestion as to what I should implement in the
future - any suggestions or questions are welcomed.

######################## OPEN SOURCE #############################

The source code is available on my github - feel free to modify
the code in any way, but without distrobuting any of my code.

######################## CONTRIBUTIONS ###########################

If you've made an improvement to the code and feel it could be in
the release version of the program, contact me and I'll have a look.
I'll give credit to any used contributions made.

######################## INSTALLATION ############################

Really, there isn't any installation. However, I would suggest creating
a shortcut of the jar file and putting it somewhere more convenient to
open (i.e. outside it's containing folder). Just make sure that you
DON'T delete the prefs.json, as the jar needs this to work.

I might also suggest moving the folder Py IDE to your program files,
or somewhere not too obstructive. As long as you make a shortcut to
Python IDE, you should be able to run the shortcut from anywhere.

